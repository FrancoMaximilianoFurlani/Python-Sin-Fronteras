# este modulo contiene una funcion que toma un valor str y lo conviente en una lista con las pocicion que
# se ensienden los led (*) en la terminal de cada numero procesado 
def numerodysplay(num):
    
      if num == '0':
            segmento1 = '***'
            segmento2 = '* *'
            segmento3 = '* *'
            segmento4 = '* *'
            segmento5 = '***'
            numero = segmento1, segmento2, segmento3, segmento4, segmento5
            return numero   
      elif num == '1':
            segmento1 = '  *'
            segmento2 = '  *'
            segmento3 = '  *'
            segmento4 = '  *'
            segmento5 = '  *'
            numero = segmento1, segmento2, segmento3, segmento4, segmento5
            return numero
        
            
      elif num == '2':
            segmento1 = '***'
            segmento2 = '  *'
            segmento3 = '***'
            segmento4 = '*  '
            segmento5 = '***'
            numero = segmento1, segmento2, segmento3, segmento4, segmento5
            return numero
      
      elif num == '3':
            segmento1 = '***'
            segmento2 = '  *'
            segmento3 = '***'
            segmento4 = '  *'
            segmento5 = '***'
            numero = segmento1, segmento2, segmento3, segmento4, segmento5
            return numero
            
      elif num == '4':
            segmento1 = '* *'
            segmento2 = '* *'
            segmento3 = '***'
            segmento4 = '  *'
            segmento5 = '  *'
            numero = segmento1, segmento2, segmento3, segmento4, segmento5
            return numero
            
      elif num == '5': 
            segmento1 = '***'
            segmento2 = '*  '
            segmento3 = '***'
            segmento4 = '  *'
            segmento5 = '***'
            numero = segmento1, segmento2, segmento3, segmento4, segmento5
            return numero
      
      elif num == '6':
            segmento1 = '***'
            segmento2 = '*  '
            segmento3 = '***'
            segmento4 = '* *'
            segmento5 = '***'
            numero = segmento1, segmento2, segmento3, segmento4, segmento5
            return numero
            
      elif num == '7':
            
            segmento1 = '***'
            segmento2 = '  *'
            segmento3 = '  *'
            segmento4 = '  *'
            segmento5 = '  *'
            numero = segmento1, segmento2, segmento3, segmento4, segmento5
            return numero
            
      elif num == '8':
            segmento1 = '***'
            segmento2 = '* *'
            segmento3 = '***'
            segmento4 = '* *'
            segmento5 = '***'
            numero = segmento1, segmento2, segmento3, segmento4, segmento5
            return numero
            
      elif num == '9':
            segmento1 = '***'
            segmento2 = '* *'
            segmento3 = '***'
            segmento4 = '  *'
            segmento5 = '  *'
            numero = segmento1, segmento2, segmento3, segmento4, segmento5
            return numero
            
    